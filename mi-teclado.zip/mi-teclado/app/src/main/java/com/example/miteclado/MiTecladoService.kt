package com.example.miteclado

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class MiTecladoService : InputMethodService() {

    private enum class Modo { LETRAS, NUMEROS, SIMBOLOS, EMOJIS }

    private var modo = Modo.LETRAS
    private var mayusculas = false
    private var bloqueoMayus = false
    private var temaActual = 0
    private val palabraActual = StringBuilder()

    private lateinit var prefs: SharedPreferences
    private lateinit var raiz: LinearLayout
    private lateinit var barraSugerencias: LinearLayout
    private lateinit var zonaTeclado: LinearLayout

    private val radioTecla by lazy { dp(14).toFloat() }

    private fun tema() = Temas.lista[temaActual]
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("mi_teclado", MODE_PRIVATE)
        temaActual = prefs.getInt("tema", 0).coerceIn(Temas.lista.indices)
    }

    override fun onCreateInputView(): View {
        raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        barraSugerencias = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        zonaTeclado = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        raiz.addView(
            barraSugerencias,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
        )
        raiz.addView(zonaTeclado)
        activarDesenfoqueDeFondo()
        dibujarTodo()
        return raiz
    }

    /** Desenfoca de verdad lo que hay detrás del teclado (Android 12 / API 31 en adelante). */
    private fun activarDesenfoqueDeFondo() {
        try {
            val win = window?.window ?: return
            win.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                win.attributes.blurBehindRadius = dp(55)
                win.attributes = win.attributes
            }
        } catch (e: Exception) {
            // Si el fabricante no lo permite en teclados, el cristal se queda
            // solo con el degradado de color, sin desenfoque real.
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        palabraActual.clear()
        modo = Modo.LETRAS
        mayusculas = true
        bloqueoMayus = false
        dibujarTodo()
    }

    // ---------- Construcción visual ----------

    private fun dibujarTodo() {
        raiz.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(tema().fondoA, tema().fondoB)
        )
        dibujarSugerencias()
        zonaTeclado.removeAllViews()
        when (modo) {
            Modo.LETRAS -> zonaTeclado.addView(crearLetras())
            Modo.NUMEROS -> zonaTeclado.addView(crearNumeros())
            Modo.SIMBOLOS -> zonaTeclado.addView(crearSimbolos())
            Modo.EMOJIS -> zonaTeclado.addView(crearEmojis())
        }
    }

    private fun dibujarSugerencias() {
        barraSugerencias.removeAllViews()

        val botonTema = aplicarCristal(TextView(this).apply {
            text = "🎨"
            textSize = 18f
            gravity = Gravity.CENTER
            setOnClickListener {
                temaActual = (temaActual + 1) % Temas.lista.size
                prefs.edit().putInt("tema", temaActual).apply()
                dibujarTodo()
            }
        }, especial = true)
        barraSugerencias.addView(
            botonTema,
            LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
        )

        val sugerencias = Dictionario.sugerencias(palabraActual.toString())
        if (sugerencias.isEmpty()) {
            val vacio = TextView(this).apply {
                text = tema().nombre
                setTextColor(tema().texto)
                alpha = 0.55f
                textSize = 13f
                gravity = Gravity.CENTER
            }
            barraSugerencias.addView(
                vacio,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            )
            return
        }
        sugerencias.forEach { palabra ->
            val v = aplicarCristal(TextView(this).apply {
                text = palabra
                setTextColor(tema().texto)
                textSize = 15f
                gravity = Gravity.CENTER
                setOnClickListener { completarPalabra(palabra) }
            }, especial = false)
            barraSugerencias.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                }
            )
        }
    }

    private fun fila(vararg vistas: View): LinearLayout {
        val f = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        vistas.forEach { f.addView(it) }
        return f
    }

    private fun contenedorFilas(vararg filas: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        filas.forEach {
            c.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        }
        return c
    }

    /** Capas de cristal líquido: relleno translúcido + brillo superior + borde de luz + sombra. */
    private fun <V : View> aplicarCristal(vista: V, especial: Boolean): V {
        val alphaRelleno = if (especial) 0x4A else 0x26
        val relleno = GradientDrawable().apply {
            cornerRadius = radioTecla
            setColor((alphaRelleno shl 24) or 0x00FFFFFF)
        }
        val brillo = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x66FFFFFF, 0x00FFFFFF)
        ).apply { cornerRadius = radioTecla }
        val borde = GradientDrawable().apply {
            cornerRadius = radioTecla
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), 0x4DFFFFFF)
        }
        val capas = LayerDrawable(arrayOf(relleno, brillo, borde))
        capas.setLayerInset(1, 0, 0, 0, dp(24))
        vista.background = capas
        vista.elevation = dp(3).toFloat()
        vista.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                if (view.width > 0 && view.height > 0) {
                    outline.setRoundRect(0, 0, view.width, view.height, radioTecla)
                }
            }
        }
        return vista
    }

    /** Tecla normal de letra/número/símbolo, peso 1. */
    private fun tecla(texto: String, accion: () -> Unit): Button {
        val b = Button(this).apply {
            text = texto
            isAllCaps = false
            textSize = 18f
            setTextColor(tema().texto)
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            setOnClickListener { accion() }
        }
        return aplicarCristal(b, especial = false)
    }

    /** Tecla especial (shift, backspace, enter...) con peso configurable. */
    private fun teclaEspecial(texto: String, peso: Float, accion: () -> Unit): Button {
        val b = Button(this).apply {
            text = texto
            isAllCaps = false
            textSize = 16f
            setTextColor(tema().acento)
            typeface = Typeface.DEFAULT_BOLD
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, peso).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            setOnClickListener { accion() }
        }
        return aplicarCristal(b, especial = true)
    }

    // ---------- Teclado de letras ----------

    private fun crearLetras(): LinearLayout {
        fun c(s: String) = if (mayusculas) s.uppercase() else s

        val f1 = fila(
            *("qwertyuiop").map { tecla(c(it.toString())) { escribir(c(it.toString())) } }.toTypedArray()
        )
        val f2 = fila(
            *("asdfghjklñ").map { tecla(c(it.toString())) { escribir(c(it.toString())) } }.toTypedArray()
        )
        val f3 = fila(
            teclaEspecial(if (bloqueoMayus) "⇪" else "⇧", 1.5f) {
                if (mayusculas && !bloqueoMayus) {
                    bloqueoMayus = true
                } else if (bloqueoMayus) {
                    bloqueoMayus = false
                    mayusculas = false
                } else {
                    mayusculas = true
                }
                dibujarTodo()
            },
            *("zxcvbnm").map { tecla(c(it.toString())) { escribir(c(it.toString())) } }.toTypedArray(),
            teclaEspecial("⌫", 1.5f) { borrar() }
        )
        val f4 = fila(
            teclaEspecial("?123", 1.3f) { modo = Modo.NUMEROS; dibujarTodo() },
            teclaEspecial("😊", 1f) { modo = Modo.EMOJIS; dibujarTodo() },
            tecla(",") { escribir(",") },
            teclaEspecial("espacio", 4f) { escribir(" ") },
            tecla(".") { escribir(".") },
            teclaEspecial("Intro", 1.5f) { intro() }
        )
        return contenedorFilas(f1, f2, f3, f4)
    }

    // ---------- Teclado de números ----------

    private fun crearNumeros(): LinearLayout {
        val f1 = fila(*("1234567890").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray())
        val f2 = fila(*("@#$_&-+()/").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray())
        val f3 = fila(
            teclaEspecial("=\\<", 1.5f) { modo = Modo.SIMBOLOS; dibujarTodo() },
            *("*\"':;!?").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray(),
            teclaEspecial("⌫", 1.5f) { borrar() }
        )
        val f4 = fila(
            teclaEspecial("ABC", 1.3f) { modo = Modo.LETRAS; dibujarTodo() },
            teclaEspecial("😊", 1f) { modo = Modo.EMOJIS; dibujarTodo() },
            tecla(",") { escribir(",") },
            teclaEspecial("espacio", 4f) { escribir(" ") },
            tecla(".") { escribir(".") },
            teclaEspecial("Intro", 1.5f) { intro() }
        )
        return contenedorFilas(f1, f2, f3, f4)
    }

    private fun crearSimbolos(): LinearLayout {
        val f1 = fila(*("~`|•√π÷×¶∆").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray())
        val f2 = fila(*("£¢€¥^°={}").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray())
        val f3 = fila(
            teclaEspecial("123", 1.5f) { modo = Modo.NUMEROS; dibujarTodo() },
            *("\\©®™℅[]").map { tecla(it.toString()) { escribir(it.toString()) } }.toTypedArray(),
            teclaEspecial("⌫", 1.5f) { borrar() }
        )
        val f4 = fila(
            teclaEspecial("ABC", 1.3f) { modo = Modo.LETRAS; dibujarTodo() },
            teclaEspecial("😊", 1f) { modo = Modo.EMOJIS; dibujarTodo() },
            tecla(",") { escribir(",") },
            teclaEspecial("espacio", 4f) { escribir(" ") },
            tecla(".") { escribir(".") },
            teclaEspecial("Intro", 1.5f) { intro() }
        )
        return contenedorFilas(f1, f2, f3, f4)
    }

    // ---------- Panel de emojis ----------

    private fun crearEmojis(): LinearLayout {
        val emojis = listOf(
            "😀","😂","😍","😉","😎","🥳","😭","😡","🤔","😴",
            "👍","👎","🙏","👏","💪","🤝","✌️","👋","🔥","💯",
            "❤️","💔","💖","⭐","✨","🎉","🎂","🌹","☀️","🌙",
            "🍕","🍔","☕","🍺","🍻","⚽","🏀","🎮","🚗","✈️"
        )
        val contenedor = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val encabezado = fila(
            teclaEspecial("ABC", 2f) { modo = Modo.LETRAS; dibujarTodo() },
            teclaEspecial("⌫", 1f) { borrar() }
        )
        contenedor.addView(
            encabezado, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
        )
        val scroll = HorizontalScrollView(this)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in 0 until 10) {
            val colLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            for (fila in 0 until 4) {
                val idx = fila * 10 + col
                if (idx < emojis.size) {
                    colLayout.addView(
                        tecla(emojis[idx]) { escribirEmoji(emojis[idx]) },
                        LinearLayout.LayoutParams(dp(48), dp(48))
                    )
                }
            }
            grid.addView(colLayout)
        }
        scroll.addView(grid)
        contenedor.addView(
            scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4 * 48))
        )
        return contenedor
    }

    // ---------- Acciones de escritura ----------

    private fun escribir(c: String) {
        currentInputConnection?.commitText(c, 1)
        if (c == " ") {
            palabraActual.clear()
        } else if (c.length == 1 && c[0].isLetter()) {
            palabraActual.append(c.lowercase())
        } else {
            palabraActual.clear()
        }
        if (mayusculas && !bloqueoMayus) {
            mayusculas = false
            dibujarTodo()
        } else {
            dibujarSugerencias()
        }
    }

    private fun escribirEmoji(e: String) {
        currentInputConnection?.commitText(e, 1)
    }

    private fun completarPalabra(palabra: String) {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(palabraActual.length, 0)
        ic.commitText("$palabra ", 1)
        palabraActual.clear()
        dibujarSugerencias()
    }

    private fun borrar() {
        val ic = currentInputConnection ?: return
        if (palabraActual.isNotEmpty()) {
            palabraActual.deleteCharAt(palabraActual.length - 1)
        }
        ic.deleteSurroundingText(1, 0)
        dibujarSugerencias()
    }

    private fun intro() {
        val ic = currentInputConnection ?: return
        val accion = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        val esMultilinea = (currentInputEditorInfo?.inputType ?: 0) and
            InputType.TYPE_TEXT_FLAG_MULTI_LINE != 0
        if (!esMultilinea && accion != null && accion != EditorInfo.IME_ACTION_NONE &&
            accion != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(accion)
        } else {
            ic.commitText("\n", 1)
        }
        palabraActual.clear()
        dibujarSugerencias()
    }
}
