package com.example.miteclado

/**
 * Diccionario simple en español para la predicción. Son solo palabras
 * comunes con un peso de frecuencia; no se conecta a internet.
 */
object Dictionario {

    // palabra a frecuencia (mayor = más común)
    private val palabras: Map<String, Int> = listOf(
        "que" to 100, "de" to 99, "no" to 98, "la" to 97, "el" to 96,
        "en" to 95, "y" to 94, "a" to 93, "los" to 92, "se" to 91,
        "del" to 90, "las" to 89, "un" to 88, "por" to 87, "con" to 86,
        "una" to 85, "su" to 84, "para" to 83, "es" to 82, "al" to 81,
        "lo" to 80, "como" to 79, "mas" to 78, "pero" to 77, "sus" to 76,
        "le" to 75, "ya" to 74, "o" to 73, "este" to 72, "si" to 71,
        "porque" to 70, "esta" to 69, "entre" to 68, "cuando" to 67,
        "muy" to 66, "sin" to 65, "sobre" to 64, "tambien" to 63,
        "me" to 62, "hasta" to 61, "hay" to 60, "donde" to 59,
        "quien" to 58, "desde" to 57, "todo" to 56, "nos" to 55,
        "durante" to 54, "todos" to 53, "uno" to 52, "les" to 51,
        "ni" to 50, "contra" to 49, "otros" to 48, "ese" to 47,
        "eso" to 46, "ante" to 45, "ellos" to 44, "e" to 43,
        "esto" to 42, "mi" to 41, "antes" to 40, "algunos" to 39,
        "que" to 38, "unos" to 37, "yo" to 36, "otro" to 35,
        "otras" to 34, "otra" to 33, "el" to 32, "tanto" to 31,
        "esa" to 30, "estos" to 29, "mucho" to 28, "quienes" to 27,
        "nada" to 26, "muchos" to 25, "cual" to 24, "poco" to 23,
        "ella" to 22, "estar" to 21, "estas" to 20, "algunas" to 19,
        "algo" to 18, "nosotros" to 17, "mi" to 16, "mis" to 15,
        "tu" to 14, "tus" to 13, "ellas" to 12, "nosotras" to 11,
        "vosotros" to 10, "vosotras" to 9, "os" to 8, "mio" to 7,
        "mia" to 6, "mios" to 5, "mias" to 4, "tuyo" to 3, "tuya" to 2,
        "gracias" to 95, "hola" to 94, "bien" to 90, "vale" to 70,
        "claro" to 68, "buenas" to 66, "adios" to 60, "porfavor" to 20,
        "favor" to 55, "amor" to 50, "casa" to 60, "trabajo" to 58,
        "tiempo" to 56, "dia" to 70, "noche" to 55, "semana" to 50,
        "hoy" to 72, "manana" to 60, "ahora" to 65, "luego" to 55,
        "pronto" to 48, "quiero" to 60, "puedo" to 58, "puedes" to 56,
        "necesito" to 54, "ayuda" to 52, "ok" to 65, "vale" to 60,
        "jaja" to 50, "jajaja" to 48, "feliz" to 45, "cumpleanos" to 30,
        "celular" to 40, "mensaje" to 42, "llamada" to 38, "foto" to 44,
        "video" to 40, "musica" to 38
    ).groupBy({ it.first }, { it.second })
        .mapValues { it.value.max() }

    private val lista: List<String> = palabras.keys.sortedByDescending { palabras[it] }

    /** Hasta [max] sugerencias cuyo inicio coincide con [prefijo] (minúsculas, sin acentos exigidos). */
    fun sugerencias(prefijo: String, max: Int = 3): List<String> {
        if (prefijo.isEmpty()) return emptyList()
        val p = prefijo.lowercase()
        return lista.filter { it.startsWith(p) && it != p }.take(max)
    }
}
