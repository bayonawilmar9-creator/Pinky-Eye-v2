package com.example.miteclado

data class Tema(
    val nombre: String,
    val fondoA: Int,
    val fondoB: Int,
    val texto: Int,
    val acento: Int
)

object Temas {
    // Cada tema define un degradado de fondo (fondoA -> fondoB) semitransparente
    // para que el desenfoque de lo que hay detrás del teclado se note,
    // y las teclas se dibujan encima como cristal translúcido.
    val lista = listOf(
        Tema(
            nombre = "Cristal rosa",
            fondoA = 0xD9230A3D.toInt(),
            fondoB = 0xD9120620.toInt(),
            texto = 0xFFF7F2FA.toInt(),
            acento = 0xFFFF57B0.toInt()
        ),
        Tema(
            nombre = "Cristal claro",
            fondoA = 0xD9F2F3F8.toInt(),
            fondoB = 0xD9D7DCEF.toInt(),
            texto = 0xFF1C1C1E.toInt(),
            acento = 0xFF0A84FF.toInt()
        ),
        Tema(
            nombre = "Cristal noche",
            fondoA = 0xD9172338.toInt(),
            fondoB = 0xD90A0F1C.toInt(),
            texto = 0xFFE6ECFF.toInt(),
            acento = 0xFF4DA8FF.toInt()
        ),
        Tema(
            nombre = "Cristal menta",
            fondoA = 0xD9123326.toInt(),
            fondoB = 0xD9081A14.toInt(),
            texto = 0xFFE6FFF2.toInt(),
            acento = 0xFF3DFFC0.toInt()
        )
    )
}
